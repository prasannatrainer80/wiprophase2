
const First = () => {
    return(
        <div>
            This is My First Functional Component...
        </div>
    )
}

export default First;