
const Second = () => {
    return(
        <div>
            This is my Second Component...Fc Example
        </div>
    )
}

export default Second