import Menu from "../menu/menu"

const Second = () => {
    return(
        <div>
            <Menu />
            This is my Second Component...Fc Example
        </div>
    )
}

export default Second